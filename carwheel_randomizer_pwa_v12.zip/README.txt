_carwheel Randomizer PWA – V12

Upload the ENTIRE contents of this folder to an HTTPS host such as GitHub Pages,
Cloudflare Pages or Netlify. Keep all files together.

Install on iPhone:
1. Open the hosted URL in Safari.
2. Tap Share.
3. Tap "Add to Home Screen".
4. Launch "_carwheel" from the Home Screen.

After the first successful load, the app shell is cached for offline use.
Edited options and the current build are saved locally in the browser.
